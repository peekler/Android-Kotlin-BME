package hu.bute.daai.amorg.education.ultimate.play

import com.google.android.gms.games.Games

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions

abstract class PlayGamesServicesActivity : AppCompatActivity() {

    private var account: GoogleSignInAccount? = null



    protected fun signIn() {
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_GAMES_SIGN_IN)
                .requestEmail()
                .build()
        val googleSignInClient = GoogleSignIn.getClient(this, options)
        val signInIntent = googleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        try {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account = task.result
            this.account = account

            onConnected()

        } catch (t: Exception) {
            t.printStackTrace()
        }
    }

    abstract fun onConnected()

    fun showAchievement(achievementId: String) {
        if (account != null) {
            Games.getAchievementsClient(this, account!!).unlock(achievementId)
        }
    }

    fun incrementAchievement(achievementId: String) {
        if (account != null) {
            Games.getAchievementsClient(this, account!!).increment(achievementId, 1)
        }

    }

    fun launchAchievements() {
        if (account != null) {
            Games.getAchievementsClient(this, account!!).achievementsIntent.addOnSuccessListener {
                startActivityForResult(it, REQUEST_ACHIEVEMENTS)
            }
        }
    }

    fun submitScore(leaderBoardId: String, score: Long) {
        if (account != null) {
            Games.getLeaderboardsClient(this, account!!).submitScore(leaderBoardId, score)
        }

    }

    fun launchLeaderBoard(leaderBoardID: String) {
        if (account != null) {
            Games.getLeaderboardsClient(this, account!!).getLeaderboardIntent(leaderBoardID).addOnSuccessListener {
                startActivityForResult(it, REQUEST_LEADERBOARDS)
            }
        }
    }

    companion object {
        private val REQUEST_ACHIEVEMENTS = 101
        private val REQUEST_LEADERBOARDS = 102
        private val RC_SIGN_IN = 201
    }
}

