package hu.bute.daai.amorg.education.ultimate.ui

import android.content.Intent
import android.os.Bundle

import hu.bute.daai.amorg.education.ultimate.R
import hu.bute.daai.amorg.education.ultimate.play.PlayGamesServicesActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : PlayGamesServicesActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar!!.setTitle("")

        signInButton.setOnClickListener {
            signIn()
        }
    }


    override fun onConnected() {
        val intent = Intent(this, GameActivity::class.java)
        startActivity(intent)
    }
}
