package hu.bute.daai.amorg.education.ultimate.model

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey


@Entity
data class User(
        @PrimaryKey var id: Long,
        @ColumnInfo(name = "score") var score: Long
)