package hu.bute.daai.amorg.education.ultimate.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem

import hu.bute.daai.amorg.education.ultimate.R
import hu.bute.daai.amorg.education.ultimate.database.GameDatabase
import hu.bute.daai.amorg.education.ultimate.model.User
import hu.bute.daai.amorg.education.ultimate.play.PlayGamesServicesActivity
import kotlinx.android.synthetic.main.activity_game.*

class GameActivity : PlayGamesServicesActivity() {


    companion object {
        val LEADER_BOARD_ID = "CgkI9bqk_5ccEAIQAw"
        val ACHIEVEMENT_1_ID = "CgkI9bqk_5ccEAIQAg"
        val ACHIEVEMENT_100_ID = "CgkI9bqk_5ccEAIQBA"
        val ACHIEVEMENT_200_ID = "CgkI9bqk_5ccEAIQBQ"
        val ACHIEVEMENT_1000_ID = "CgkI9bqk_5ccEAIQBg"
    }


    private var gameDatabase: GameDatabase? = null
    private var user: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        supportActionBar!!.title = ""
        signIn()
    }

    override fun onConnected() {
        gameDatabase = GameDatabase(applicationContext)

        user = gameDatabase!!.queryUser()
        if (user == null) {
            needCoffeeTV!!.text = "You have drunk no coffee!"
            gameDatabase!!.createUser()
        } else {
            needCoffeeTV!!.text = "You have drunk " + user!!.score + " coffee!"

        }

        needCoffeeBTN.setOnClickListener {
            var score = user!!.score
            score += 1
            gameDatabase!!.update(user!!)
            needCoffeeTV!!.text = "You have drunk " + user!!.score + " coffee!"
            showAchievement(ACHIEVEMENT_1_ID)
            incrementAchievement(ACHIEVEMENT_100_ID)
            incrementAchievement(ACHIEVEMENT_200_ID)
            incrementAchievement(ACHIEVEMENT_1000_ID)
            submitScore(LEADER_BOARD_ID, score)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_game, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId

        if (id == R.id.action_achievements) {
            this.launchAchievements()
            return true
        }

        if (id == R.id.action_leaderboards) {
            this.launchLeaderBoard(LEADER_BOARD_ID)
            return true
        }

        return super.onOptionsItemSelected(item)
    }


}
