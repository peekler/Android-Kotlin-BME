package hu.bute.daai.amorg.education.ultimate.database

import android.arch.persistence.room.Room
import android.content.Context

import hu.bute.daai.amorg.education.ultimate.model.User
import hu.bute.daai.amorg.education.ultimate.model.UserDatabase

class GameDatabase(context: Context) {
    private val db = Room.databaseBuilder(context, UserDatabase::class.java, "user-database").build()

    fun createUser(): User {
        val user = User(id = 1, score = 0)
        db.userDao().insertAll(user)
        return user
    }

    fun queryUser(): User? {
        return db.userDao().getAll().firstOrNull()
    }

    fun update(user: User) {
        db.userDao().update(user)
    }
}
